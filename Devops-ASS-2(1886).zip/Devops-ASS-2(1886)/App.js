import React, { useState } from "react";
import StudentProfileFunction from "./StudentProfileFunction";

function App() {
  const [show, setShow] = useState(true);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Lifecycle Demo (Function)</h1>

      <button onClick={() => setShow(!show)}>
        {show ? "Hide" : "Show"} Student Profile
      </button>

      {show && <StudentProfileFunction />}
    </div>
  );
}

export default App;