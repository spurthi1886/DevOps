import React, { Component } from "react";

class StudentProfile extends Component {
  constructor(props) {
    super(props);
    this.state = { student: null };
    console.log("Constructor called");
  }

  componentDidMount() {
    console.log("Component mounted");

    setTimeout(() => {
      this.setState({
        student: {
          name: "Spurthi",
          course: "B.Tech",
          year: "3rd Year",
        },
      });
    }, 1000);
  }

  componentDidUpdate() {
    console.log("Component updated");
  }

  componentWillUnmount() {
    console.log("Component unmounted");
  }

  render() {
    return (
      <div style={{ border: "2px solid black", padding: "15px" }}>
        <h2>Student Profile</h2>
        {this.state.student ? (
          <>
            <p>Name: {this.state.student.name}</p>
            <p>Course: {this.state.student.course}</p>
            <p>Year: {this.state.student.year}</p>
          </>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    );
  }
}

export default StudentProfile;