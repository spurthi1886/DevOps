import React, { useState } from "react";
import CartItem from "./CartItem";

function Cart() {
  const [items, setItems] = useState([
    { id: 1, name: "Laptop", price: 45000, quantity: 1 },
    { id: 2, name: "Headphones", price: 1500, quantity: 1 },
    { id: 3, name: "Keyboard", price: 1000, quantity: 1 },
    { id: 4, name: "Mouse", price: 600, quantity: 1 },
    { id: 5, name: "Monitor", price: 12000, quantity: 1 },
    { id: 6, name: "USB Cable", price: 300, quantity: 1 },
    { id: 7, name: "Power Bank", price: 1500, quantity: 1 },
    { id: 8, name: "Webcam", price: 3500, quantity: 1 }
  ]);

  const updateQuantity = (id, type) => {
    setItems(items.map(item => {
      if (item.id === id) {
        if (type === "inc") {
          return { ...item, quantity: item.quantity + 1 };
        }
        if (type === "dec" && item.quantity > 1) {
          return { ...item, quantity: item.quantity - 1 };
        }
        if (type === "reset") {
          return { ...item, quantity: 1 };
        }
      }
      return item;
    }));
  };

  const totalAmount = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <div style={{ padding: "30px", textAlign: "center" }}>
      <h1 style={{ color: "white" }}>🛍 Shopping Cart</h1>

      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
        {items.map(item => (
          <CartItem
            key={item.id}
            item={item}
            updateQuantity={updateQuantity}
          />
        ))}
      </div>

      <h2 style={{ color: "white" }}>
        Total Amount: ₹{totalAmount}
      </h2>
    </div>
  );
}

export default Cart;
