import React from "react";

function CartItem({ item, updateQuantity }) {
  return (
    <div
      style={{
        background: "white",
        borderRadius: "12px",
        padding: "20px",
        width: "220px",
        margin: "15px",
        boxShadow: "0 4px 10px rgba(0,0,0,0.2)"
      }}
    >
      <h3>{item.name}</h3>
      <p>Price: ₹{item.price}</p>
      <p>Quantity: {item.quantity}</p>
      <p><b>Total: ₹{item.price * item.quantity}</b></p>

      <div>
        <button onClick={() => updateQuantity(item.id, "inc")}>+</button>
        <button
          onClick={() => updateQuantity(item.id, "dec")}
          style={{ margin: "0 10px" }}
        >
          -
        </button>
        <button onClick={() => updateQuantity(item.id, "reset")}>
          Reset
        </button>
      </div>
    </div>
  );
}

export default CartItem;
