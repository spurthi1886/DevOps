import React from "react";
import Cart from "./Cart";

function App() {
  return <Cart />;
}

export default App;
